import Link from 'next/link'
import { Button } from "@/components/ui/button"

export default function Navbar() {
  return (
    <nav className="bg-primary text-primary-foreground p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold">Campus Vent</Link>
        <div className="space-x-4">
          <Button variant="ghost">登录</Button>
          <Button variant="secondary">注册</Button>
        </div>
      </div>
    </nav>
  )
}

